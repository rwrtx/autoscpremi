#wget https://github.com/${GitUser}/
GitUser="rwrtx"
#IZIN SCRIPT
MYIP=$(curl -sS ipv4.icanhazip.com)
echo -e "\e[32mloading...\e[0m"
clear
# Valid Script
VALIDITY () {
    today=`date -d "0 days" +"%Y-%m-%d"`
    Exp1=$(curl https://raw.githubusercontent.com/${GitUser}//vvipsc/main/izin | grep $MYIP | awk '{print $4}')
    if [[ $today < $Exp1 ]]; then
    echo -e "\e[32mYOUR SCRIPT ACTIVE..\e[0m"
    else
    echo -e "\e[31mYOUR SCRIPT HAS EXPIRED!\e[0m";
    echo -e "\e[31mPlease renew your ipvps first\e[0m"
    exit 0
fi
}
IZIN=$(curl https://raw.githubusercontent.com/${GitUser}/vvipsc/main/izin | awk '{print $5}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo -e "\e[32mPermission Accepted...\e[0m"
VALIDITY
else
echo -e "\e[31mPermission Denied!\e[0m";
echo -e "\e[31mPlease buy script first\e[0m"
exit 0
fi
echo -e "\e[32mloading...\e[0m"
clear
red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
MYIP=$(wget -qO- ifconfig.me/ip);
clear
# Acc ID Clf
mkdir -p /root/
touch /root/mail.conf
IP=$(wget -qO- ifconfig.me/ip);
cloudflare=$(grep -c -E "^### " "/root/mail.conf")
if [[ ${cloudflare} == '0' ]]; then
        echo ""
		echo ""
		echo -e "\e[1;31mYou Have No ID CLOUDFLARE! Please ADD ID Coudflare First.\e[0m"
		echo -e "\e[1;31mBack To Main Menu, Thankyou.\e[0m"
		exit 1
	fi
source /root/mail.conf
DOMAIN=$domain
CF_ID=$email
CF_KEY=$key
set -euo pipefail
read -p "Masukan Subdomain Anda :" sub
read -p "Masukan Ip Yang Anda Ingin Pointing :" IP
echo "Updating DNS for ${sub}..."
ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${DOMAIN}&status=active" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${sub}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

if [[ "${#RECORD}" -le 10 ]]; then
     RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${sub}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
fi

RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${sub}'","content":"'${IP}'","ttl":120,"proxied":false}')
clear
echo ""
echo -e " \e[1;36mSuccesfully Add your Subdomain\e[0m"
echo -e " \e[0;34m======================================\e[0m"
echo -e " \e[0;33mDomain Name        :\e[0m $DOMAIN"
echo -e " \e[0;33mSubdomain Name     :\e[0m ${sub}"
echo -e " \e[0;33mYour IP Pointing   :\e[0m ${IP}"
echo -e " \e[0;33mSub + Domain (Used):\e[0m ${sub}.$DOMAIN"
echo -e " \e[0;34m======================================\e[0m"
echo ""
echo -e "\e[0;32mDONE...!\e[0m"
