#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# System Request : Debian 9+/Ubuntu 18.04+/20+
# Develovers » R32WRT_STORE
# telegram   » https://t.me/R32WRT_STORE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ꧁༒༺  𝐑𝟑𝟐𝐖𝐑𝐓𝐱 𝐓𝐔𝐍𝐍𝐄𝐋𝐈𝐍𝐆 ༻༒꧂
# COLOR VALIDATION
clear
BOLD="\e[1m"
UNDERLINE="\e[4m"
y='\033[1;33m' #yellow
l='\033[0;37m'
BGX="\033[42m"
CYAN="\033[96m"
z="\033[93;1m" # // Hijau
zx="\033[97;1m" # // putih
RED='\033[0;31m'
BICyan='\033[1;96m'       # Cyan
NC='\033[0m'
gray="\e[1;30m"
Blue="\033[0;34m"
green='\033[92;1m'
grenbo="\e[92;1m"
purple="\033[1;95m"
YELL='\033[0;33m'
cyan="\033[1;36m"

# // installer Udp
UDPX="https://docs.google.com/uc?export=download&confirm=$(wget --quiet --save-cookies /tmp/cookies.txt --keep-session-cookies --no-check-certificate 'https://docs.google.com/uc?export=download&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2' -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2"

# // Gettings Info
ISP=$(cat /etc/xray/isp)
CITY=$(cat /etc/xray/city)
IPVPS=$(curl -s ipv4.icanhazip.com)
domain=$(cat /etc/xray/domain)
RAM=$(free -m | awk 'NR==2 {print $2}')
USAGERAM=$(free -m | awk 'NR==2 {print $3}')
MEMOFREE=$(printf '%-1s' "$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')")
LOADCPU=$(printf '%-0.00001s' "$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')")
MODEL=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/"//g' | sed 's/PRETTY_NAME//g')
CORE=$(printf '%-1s' "$(grep -c cpu[0-9] /proc/stat)")
DATEVPS=$(date +'%d/%m/%Y')
TIMEZONE=$(printf '%(%H:%M:%S)T')
SERONLINE=$(uptime -p | cut -d " " -f 2-10000)

clear
MYIP=$(curl -sS ipv4.icanhazip.com)
echo ""
#########################
# // USERNAME IZIN IPP
rm -f /usr/bin/user
username=$(curl -sS https://raw.githubusercontent.com/rwrtx/vvipsc/main/izin | grep $MYIP | awk '{print $2}')
echo "$username" >/usr/bin/user

# // VALIDITY
rm -f /usr/bin/e
valid=$(curl -sS https://raw.githubusercontent.com/rwrtx/vvipsc/main/izin | grep $MYIP | awk '{print $3}')
echo "$valid" > /usr/bin/e

# // DETAIL ORDER IZIN IP
username=$(cat /usr/bin/user)
oid=$(cat /usr/bin/ver)
exp=$(cat /usr/bin/e)

clear
# // DAYS LEFT
d1=$(date -d "$valid" +%s)
d2=$(date -d "$today" +%s)
certifacate=$(((d1 - d2) / 86400))

# // VPS INFORMATION
DATE=$(date +'%Y-%m-%d')
datediff() {
    d1=$(date -d "$1" +%s)
    d2=$(date -d "$2" +%s)
    echo -e "$COLOR1 $NC Expiry In   : $(( (d1 - d2) / 86400 )) Days"
}
mai="datediff "$Exp" "$DATE""

# Status ExpiRED Active |

# // AKTIVATED & EXPIRED
Info="${green}Activated${NC}"
Error="${RED}Expired ${NC}"
#//
today=`date -d "0 days" +"%Y-%m-%d"`
Exp1=$(curl -sS https://raw.githubusercontent.com/rwrtx/vvipsc/main/izin | grep $MYIP | awk '{print $3}')
if [[ $today < $Exp1 ]]; then
sts="${Info}"
else
sts="${Error}"
fi
echo -e "\e[32mloading...\e[0m"
clear

# // GETTINGS SYSTEM
uptime="$(uptime -p | cut -d " " -f 2-10)"
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${coREDiilik:-1}))"
cpu_usage+=" %"
WKT=$(curl -s ipinfo.io/timezone )
DAY=$(date +%A)
DATE=$(date +%m/%d/%Y)
DATE2=$(date -R | cut -d " " -f -5)

#IPVPS=$(curl -s ipinfo.io/ip )
IPVPS=$(curl -sS ipv4.icanhazip.com)

cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
tram=$( free -m | awk 'NR==2 {print $2}' )
uram=$( free -m | awk 'NR==2 {print $3}' )
fram=$( free -m | awk 'NR==2 {print $4}' )
clear
ssh_service=$(/etc/init.d/ssh status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
dropbear_service=$(/etc/init.d/dropbear status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
haproxy_service=$(systemctl status haproxy | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
xray_service=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
nginx_service=$(systemctl status nginx | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
#Status | Geo Project
clear


# // RUNNING SSH
if [[ $ssh_service == "running" ]]; then 
   status_ssh="${green}ON✓${NC}"
else
   status_ssh="${RED}🔴${NC} "
fi

# // RUNNING WEBSOCKET
ssh_ws=$( systemctl status ws | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $ssh_ws == "running" ]]; then
    status_ws_epro="${green}ON✓${NC}"
else
    status_ws_epro="${RED}🔴${NC} "
fi

# RUNNING HAPROXY
if [[ $haproxy_service == "running" ]]; then 
   status_haproxy="${green}ON✓${NC}"
else
   status_haproxy="${RED}🔴${NC} "
fi

# RUNNING XRAY
if [[ $xray_service == "running" ]]; then 
   status_xray="${green}ON✓${NC}"
else
   status_xray="${RED}🔴${NC} "
fi

# RUNNING NGINX
if [[ $nginx_service == "running" ]]; then 
   status_nginx="${green}ON✓${NC}"
else
   status_nginx="${RED}🔴${NC} "
fi

# RUNNING DROPBEAR
if [[ $dropbear_service == "running" ]]; then 
   status_dropbear="${green}ON✓${NC}"
else
   status_dropbear="${RED}🔴${NC} "
fi
# // UPDATE / REVISI all menu
REVISI="https://raw.githubusercontent.com/rwrtx/autoscpremi/main/"

# // INFO CREATE ACCOUNT
# \\ Vless account //
vlx=$(grep -c -E "^#& " "/etc/xray/config.json")
let vla=$vlx/2
# \\ Vmess account //
vmc=$(grep -c -E "^### " "/etc/xray/config.json")
let vma=$vmc/2
# \\ Trojan account //
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
trx=$(grep -c -E "^#! " "/etc/xray/config.json")
let trb=$trx/2
# \\ shadowsocks account //
ssx=$(grep -c -E "^#!# " "/etc/xray/config.json")
let ssa=$ssx/2
# // ---- >>>
TZ="\033[1;35m___\033[1;34m___\033[1;32m___\033[1;36m___\033[1;37m___\033[1;34m"
vers="version.Sc 3.09"
# // ----->>>
r="\033[1;31m"  #REDTERANG
a=" ${z}ACCOUNT${NC}" 
BG_RED="\033[45;1m"
BICyan='\033[1;96m'       # Cyan
RED_BG_BOLD="\e[1;41m"
GREEN_BG_BOLD="\e[1;42m"
YELLOW_BG_BOLD="\e[1;43m"
BLUE_BG_BOLD="\e[1;44m"
MAGENTA_BG_BOLD="\e[1;45m"
CYAN_BG_BOLD="\e[1;46m"
G='\033[35;1m'
clear
echo -e ""
echo -e " ${r}══════════════════════════════════════$NC"
echo -e " $NC\e[1;41m        EXTRA SYSTEM VPS MENU         $NC"
echo -e " ${r}══════════════════════════════════════$NC"
echo -e "   $NC(•1)$NC ${r}Add New Subdomain$NC"
echo -e "   $NC(•2)$NC ${r}Renew Cert Ssl Subdomain Xray$NC"
echo -e "   $NC(•3)$NC ${r}Add NameServer$NC"
echo -e "   $NC(•4)$NC ${r}Setup Speed VPS$NC"
echo -e "   $NC(•5)$NC ${r}Panel Domain CF (Owner Only Access)$NC"
echo -e "   $NC(•6)$NC ${r}Backup Vps$NC"
echo -e "   $NC(•7)$NC ${r}Autobackup Vps$NC"
echo -e "   $NC(•8)$NC ${r}Restore Vps$NC"
echo -e "   $NC(•9)$NC ${r}Install Bot Telegram$NC"
echo -e "   $NC(10)$NC ${r}Reboot VPS$NC"
echo -e "   $NC(11)$NC ${r}Restart VPN$NC"
echo -e "   $NC(12)$NC ${r}Speedtest VPS$NC"
echo -e "   $NC(13)$NC ${r}Info All Port$NC"
echo -e "   $NC(14)$NC ${r}Check Bandwith$NC"
echo -e "   $NC(15)$NC ${r}ON/OF Auto Reboot$NC"
echo -e "   $NC(16)$NC ${r}Change Password $NC"
echo -e "   $NC(17)$NC ${r}Edit Banner SSH/OPENVPN$NC"
echo -e "   $NC(18)$NC ${r}Show Benchmark$NC"
echo -e "   $NC(19)$NC ${r}Info Running Xray"
echo -e "   $NC(20)$NC ${r}Update Script$NC"
echo -e " ${r}══════════════════════════════════════$NC"
echo -e ""
read -p " Please Input Number [1-17 or x->(exit)] :  "  sys
echo -e ""
case $sys in
1)
clear
addhost
;;
2)
clear
fixcert
;;
3)
wget https://raw.githubusercontent.com/rwrtx/autoscpremi/main/files/cfnsdomain.sh && chmod +x cfnsdomain.sh && ./cfnsdomain.sh
;;
4)
clear
limitspeed
;;
5)
clear
panel-domain.sh
;;
6)
clear
backup
;;
7)
clear
autobackup.sh
;;
8)
clear
restore
;;
9)
m-bot
;;
10)
reboot
;;
11)
restart
;;
12)
clear
speedtest
;;
13)
clear
prot
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
menu
;;
14)
clear
bw
;;
15)
clear
autoreboot
;;
16)
clear
passwd
;;
17)
nano /etc/kyt.txt
;;
18)
clear
curl -sS -H 'Cache-Control: no-cache, no-store' https://raw.githubusercontent.com/rwrtx/bench/main/bench.sh | bash
;;
19)
run
;;
20)
clear
wget -q https://raw.githubusercontent.com/rwrtx/autoscpremi/main/update.sh && chmod +x update.sh && ./update.sh
;;
x)
clear
figlet R32WRTx TUNNELING | lolcat 
clear
menu
;;
*)
echo "Please enter an correct number"
sleep 1
system
;;
esac