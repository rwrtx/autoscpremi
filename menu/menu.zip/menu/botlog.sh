#!/bin/bash

# Direktori dan file konfigurasi bot
CONFIG_DIR="/etc/kyt/bot"
BOT_CONFIG="$CONFIG_DIR/bot_config"
mkdir -p "$CONFIG_DIR"

# Load konfigurasi bot
if [[ ! -f "$BOT_CONFIG" ]]; then
    echo "Konfigurasi bot tidak ditemukan. Pastikan bot diinstal terlebih dahulu."
    exit 1
fi
source "$BOT_CONFIG"

# Fungsi mengirim notifikasi Telegram
send_notification() {
    local message="$1"
    curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
        -d chat_id="${CHAT_ID}" \
        -d text="${message}" \
        -d parse_mode="HTML" >/dev/null || echo "Gagal mengirim notifikasi"
}

# Fungsi cek log SSH
check_ssh_logins() {
    local notification="<b>🔔 SSH Logins</b>\n\n"
    ssh_logs=$(grep "sshd" /var/log/auth.log | tail -n 10)

    if [[ -n "$ssh_logs" ]]; then
        notification+="$ssh_logs"
    else
        notification+="Tidak ada login SSH terbaru."
    fi

    send_notification "$notification"
}

# Fungsi cek log XRay (VMess, VLESS, Trojan)
check_xray_logins() {
    local notification="<b>🔔 XRAY Logins</b>\n\n"

    # VMess
    notification+="<b>🌀 VMess Logins:</b>\n"
    vmess_logs=$(grep -oP '.*(?=#vmess)' /var/log/xray/access.log | tail -n 5)
    if [[ -n "$vmess_logs" ]]; then
        notification+="$vmess_logs\n"
    else
        notification+="Tidak ada login VMess terbaru.\n"
    fi

    # VLESS
    notification+="\n<b>🌐 VLESS Logins:</b>\n"
    vless_logs=$(grep -oP '.*(?=#vless)' /var/log/xray/access.log | tail -n 5)
    if [[ -n "$vless_logs" ]]; then
        notification+="$vless_logs\n"
    else
        notification+="Tidak ada login VLESS terbaru.\n"
    fi

    # Trojan
    notification+="\n<b>⚡ Trojan Logins:</b>\n"
    trojan_logs=$(grep -oP '.*(?=#trojan)' /var/log/xray/access.log | tail -n 5)
    if [[ -n "$trojan_logs" ]]; then
        notification+="$trojan_logs\n"
    else
        notification+="Tidak ada login Trojan terbaru.\n"
    fi

    send_notification "$notification"
}

# Fungsi utama untuk cek semua log dan kirim notifikasi
check_and_notify() {
    echo "Memeriksa log SSH..."
    check_ssh_logins

    echo "Memeriksa log XRAY..."
    check_xray_logins

    echo "Notifikasi berhasil dikirim."
}

# Menu utama
while true; do
    clear
    echo -e "=== Menu Bot Notifikasi ==="
    echo "1. Cek & Kirim Notifikasi Sekarang"
    echo "2. Atur Interval Notifikasi Otomatis"
    echo "3. Keluar"
    read -p "Pilih menu [1-3]: " choice

    case $choice in
        1)
            check_and_notify
            ;;
        2)
            read -p "Masukkan interval waktu pengiriman notifikasi (dalam menit): " interval
            if [[ "$interval" =~ ^[0-9]+$ ]] && [[ "$interval" -gt 0 ]]; then
                (crontab -l 2>/dev/null | grep -v "bot_notifikasi.sh"; echo "*/$interval * * * * $(realpath $0)") | crontab -
                echo "Notifikasi otomatis diatur setiap $interval menit."
            else
                echo "Interval tidak valid. Masukkan angka positif."
            fi
            ;;
        3)
            echo "Keluar."
            break
            ;;
        *)
            echo "Pilihan tidak valid."
            ;;
    esac

    read -p "Tekan Enter untuk melanjutkan..."
done
